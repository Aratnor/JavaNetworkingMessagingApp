package com.example.hms;

import com.example.hms.utils.InstructionReader;

public class Main {

    public static void main(String [] args) {
        InstructionReader instructionReader = new InstructionReader();
        instructionReader.start();

    }

}
