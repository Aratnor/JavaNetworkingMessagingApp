package com.example.hms.model;

import java.util.ArrayList;
import java.util.List;

public class Admission {
    int admissionId;
    int patientId;
    List<Examination> examinations;

    public Admission(int admissionId, int patientId) {
        this.admissionId = admissionId;
        this.patientId = patientId;
        examinations = new ArrayList<>();
    }

    public int getAdmissionId() {
        return admissionId;
    }

    public void setAdmissionId(int admissionId) {
        this.admissionId = admissionId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public List<Examination> getExaminations() {
        return examinations;
    }

    public void setExaminations(List<Examination> examinations) {
        this.examinations = examinations;
    }

    public void addExamination(Examination examination) {
        examinations.add(examination);
    }
}
