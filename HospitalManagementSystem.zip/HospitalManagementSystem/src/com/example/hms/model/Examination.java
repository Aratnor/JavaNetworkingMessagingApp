package com.example.hms.model;

import com.example.hms.utils.FileConstants;

public class Examination {
    String patientType;
    String examinationType;
    String examinationValue;
    int cost;

    public Examination(String patientType, String examinationType, String examinationValue) {
        this.patientType = patientType;
        this.examinationType = examinationType;
        this.examinationValue = examinationValue;
        if( patientType.contains("in") ) {
            cost += FileConstants.inPatientCost;
        } else {
            cost += FileConstants.outPatientCost;
        }

        if( examinationType.contains("test") ) {
            cost += FileConstants.testsCost;
        } else if( examinationType.contains("imaging")) {
            cost += FileConstants.imagingCost;
        }

        if( examinationValue.contains("doctor")) {
            cost += FileConstants.doctorVisitCost;
        } else if( examinationValue.contains("measurement")) {
            cost += FileConstants.measurementCost;
        }
    }
    public String getStringValue() {
        return (patientType == null ? "" : patientType) + " " +
                (examinationType == null ? "" : examinationType) + " " +
                (examinationValue == null ? "" : examinationValue);
    }

    @Override
    public String toString() {
        return getStringValue() +  "\n";
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public String getPatientType() {
        return patientType;
    }

    public void setPatientType(String patientType) {
        this.patientType = patientType;
    }

    public String getExaminationType() {
        return examinationType;
    }

    public void setExaminationType(String examinationType) {
        this.examinationType = examinationType;
    }

    public String getExaminationValue() {
        return examinationValue;
    }

    public void setExaminationValue(String examinationValue) {
        this.examinationValue = examinationValue;
    }
}
