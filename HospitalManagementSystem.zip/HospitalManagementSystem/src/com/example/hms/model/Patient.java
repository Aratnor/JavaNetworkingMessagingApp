package com.example.hms.model;

import com.example.hms.decorator.patient.AddPatientAction;

public class Patient {
    private int patientId;
    private String patientName;
    private String patientSurname;
    private String phoneNumber;
    private String Address;

    public Patient(int patientId) {
        this.patientId = patientId;
    }

    public Patient(
            int patientId, String patientName,
            String patientSurname, String phoneNumber,
            String address) {
        this.patientId = patientId;
        this.patientName = patientName;
        this.patientSurname = patientSurname;
        this.phoneNumber = phoneNumber;
        Address = address;
    }

    public String toString() {
        return  patientId + "\t" +
                (patientName == null ? "" : patientName) + " " +
                (patientSurname == null ? "" : patientSurname) + "\t" +
                (phoneNumber == null ? "" : phoneNumber) + "\t" +
                (Address == null ? "" : Address) + "\n";
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientSurname() {
        return patientSurname;
    }

    public void setPatientSurname(String patientSurname) {
        this.patientSurname = patientSurname;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }
}
