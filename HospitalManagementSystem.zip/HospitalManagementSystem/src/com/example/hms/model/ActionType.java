package com.example.hms.model;

public enum ActionType {
    ADD,
    DELETE,
    LIST,
    ADD_EXAMINATION
}
