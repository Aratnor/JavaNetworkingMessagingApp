package com.example.hms.dao;

import com.example.hms.model.Examination;

import java.util.List;

public interface GenericDao<T> {

    void addData(T t);

    void removeData(T t);

    void listData();


}
