package com.example.hms.dao;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.patient.AddPatientAction;
import com.example.hms.decorator.patient.BasePatient;
import com.example.hms.decorator.patient.DeletePatientAction;
import com.example.hms.decorator.patient.ListPatientAction;
import com.example.hms.model.ActionType;
import com.example.hms.model.Patient;
import com.example.hms.utils.FileConstants;
import com.example.hms.utils.IOStreamManager;
import com.example.hms.utils.Utils;

import java.io.IOException;
import java.util.List;

public class PatientRepository implements GenericDao<Patient> {
    BaseAction<Patient> baseAction;

    public PatientRepository() {
        baseAction = new BasePatient();
        try {
            String [] lines = IOStreamManager.readFileByLine(FileConstants.patientFilePath);
            baseAction.setBaseList(Utils.getPatientsByInstructions(lines));
        } catch (IOException ioException) {

        }
    }
    @Override
    public void addData(Patient patient) {
        BaseAction<Patient> addAction = new AddPatientAction(baseAction);
        addAction.performAction(patient, ActionType.ADD);
    }

    @Override
    public void removeData(Patient patient) {
        DeletePatientAction deleteAction = new DeletePatientAction(baseAction);
        deleteAction.performAction(patient, ActionType.DELETE);
    }

    @Override
    public void listData() {
        BaseAction<Patient> listAction = new ListPatientAction(baseAction);
        listAction.performAction(null, ActionType.LIST);
    }


}
