package com.example.hms.dao;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.admission.*;
import com.example.hms.decorator.patient.BasePatient;
import com.example.hms.model.ActionType;
import com.example.hms.model.Admission;
import com.example.hms.model.Examination;
import com.example.hms.utils.FileConstants;
import com.example.hms.utils.IOStreamManager;
import com.example.hms.utils.Utils;

import java.io.IOException;

public class AdmissionRepository implements GenericDao<Admission> {
    BaseAction<Admission> baseAction;

    public AdmissionRepository() {
        baseAction = new BaseAdmission();
        try {
            String [] lines = IOStreamManager.readFileByLine(FileConstants.admissionFilePath);
            baseAction.setBaseList(Utils.getAdmissionByInstruction(lines));
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    @Override
    public void addData(Admission admission) {
        CreateAdmission createAdmission = new CreateAdmission(baseAction);
        createAdmission.performAction(admission, ActionType.ADD);
    }

    public void addExamination(Examination examination, int admissionId
    ) {
        AddExaminationToAdmission examinationToAdmission = new AddExaminationToAdmission(baseAction,admissionId);

        examinationToAdmission.performAction(examination, ActionType.ADD_EXAMINATION);

    }

    public void printTotalCost(int admissionId) {
        TotalCostForAdmission totalCostForAdmission = new TotalCostForAdmission(baseAction);
        totalCostForAdmission.performAction(new Admission(admissionId,-1),ActionType.LIST);
    }

    @Override
    public void removeData(Admission admission) {
        RemoveAdmission removeAdmission = new RemoveAdmission(baseAction);
        removeAdmission.performAction(admission,ActionType.DELETE);
    }

    @Override
    public void listData() {

    }
}
