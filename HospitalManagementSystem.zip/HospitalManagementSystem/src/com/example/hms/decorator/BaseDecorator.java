package com.example.hms.decorator;

import com.example.hms.model.ActionType;

public abstract class BaseDecorator<T> extends BaseAction<T> {

    public abstract void performAction(T t, ActionType actionType);
}
