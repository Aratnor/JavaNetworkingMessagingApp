package com.example.hms.decorator.admission;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Admission;
import com.example.hms.utils.Utils;

public class RemoveAdmission extends BaseDecorator<Admission> {
    BaseAction<Admission> baseAction;

    public RemoveAdmission(BaseAction<Admission> baseAction) {
        this.baseAction = baseAction;
    }

    @Override
    public void performAction(Admission admission, ActionType actionType) {
        baseAction.performAction(admission, actionType);
        Utils.removeAdmissionById(baseAction.getBaseList(),admission.getAdmissionId());
    }
}
