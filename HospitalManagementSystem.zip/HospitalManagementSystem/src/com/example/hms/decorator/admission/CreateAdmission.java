package com.example.hms.decorator.admission;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Admission;
import com.example.hms.utils.FileConstants;
import com.example.hms.utils.IOStreamManager;

import java.io.IOException;

public class CreateAdmission extends BaseDecorator<Admission> {
    BaseAction<Admission> baseAction;

    public CreateAdmission(BaseAction<Admission> baseAction) {
        this.baseAction = baseAction;
    }
    @Override
    public void performAction(Admission admission, ActionType actionType) {
        baseAction.performAction(admission,actionType);

        StringBuilder builder = new StringBuilder();
        builder
                .append("Admission").append(" ")
                .append(admission.getAdmissionId()).append(" ")
                .append("created").append("\n");
        StringBuilder builderAdmission = new StringBuilder();
        builderAdmission.append(admission.getAdmissionId()).append(" ").append(admission.getPatientId()).append("\n");
        try {
            IOStreamManager.writeFileWithAppend(FileConstants.outputTestFilePath,builder.toString());
            IOStreamManager.writeFileWithAppend(FileConstants.admissionFilePath,builderAdmission.toString());
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }
}
