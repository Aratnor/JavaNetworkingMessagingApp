package com.example.hms.decorator.admission;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Admission;
import com.example.hms.model.Examination;
import com.example.hms.utils.Utils;

public class AddExaminationToAdmission extends BaseDecorator<Examination> {
    BaseAction<Admission> baseAction;
    int admissionId;

    public AddExaminationToAdmission(BaseAction<Admission> baseAction,int admissionId) {
        this.baseAction = baseAction;
        this.admissionId = admissionId;
    }
    @Override
    public void performAction(Examination examination, ActionType actionType) {
        Utils.addExaminationToAdmission(baseAction.getBaseList(),admissionId, examination);
    }
}
