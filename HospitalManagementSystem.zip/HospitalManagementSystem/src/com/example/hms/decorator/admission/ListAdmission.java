package com.example.hms.decorator.admission;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Admission;

public class ListAdmission extends BaseDecorator<Admission> {
    BaseAction<Admission> baseAction;

    public ListAdmission(BaseAction<Admission> baseAction) {
        this.baseAction = baseAction;
    }
    @Override
    public void performAction(Admission admission, ActionType actionType) {

    }
}
