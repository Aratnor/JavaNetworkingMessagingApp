package com.example.hms.decorator.admission;

import com.example.hms.decorator.BaseAction;
import com.example.hms.model.ActionType;
import com.example.hms.model.Admission;
import com.example.hms.model.Examination;

public class BaseAdmission extends BaseAction<Admission> {

    @Override
    public void performAction(Admission admission, ActionType actionType) {
        switch (actionType) {
            case ADD:addAdmission(admission); break;
        }
    }

    public void addAdmission(Admission admission) {
        baseList.add(admission);
    }

}
