package com.example.hms.decorator.admission;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Admission;
import com.example.hms.model.Examination;
import com.example.hms.utils.FileConstants;
import com.example.hms.utils.IOStreamManager;
import com.example.hms.utils.Utils;

import java.io.IOException;

public class TotalCostForAdmission extends BaseDecorator<Admission> {

    BaseAction<Admission> baseAction;

    public TotalCostForAdmission(BaseAction<Admission> baseAction) {
        this.baseAction = baseAction;
    }

    @Override
    public void performAction(Admission admission, ActionType actionType) {
        Admission getAdmissionFromList = Utils.getAdmissionById(baseAction.getBaseList(), admission.getAdmissionId());

        StringBuilder builder = new StringBuilder();
        if (getAdmissionFromList != null) {
            builder.append("Total cost for admission : ").append(getAdmissionFromList.getAdmissionId()).append("\n");
            for(Examination examination : getAdmissionFromList.getExaminations()) {
                builder
                        .append("\t")
                        .append(examination.getStringValue())
                        .append( " ")
                        .append(examination.getCost())
                        .append("$")
                        .append("\n");
            }
        }
        try {
            IOStreamManager.writeFileWithAppend(FileConstants.outputTestFilePath,builder.toString());
        } catch (IOException ioException) {
            Utils.showIOErrorMessage();
        }
    }
}
