package com.example.hms.decorator;

import com.example.hms.model.ActionType;
import com.example.hms.utils.IOStreamManager;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseAction<T> {
    protected List<T> baseList;

    public BaseAction() {
        baseList = new ArrayList<T>();
    }

    public List<T> getBaseList() {
        return baseList;
    }

    public void setBaseList(List<T> list) {
        baseList = list;
    }

    public abstract void performAction(T t, ActionType actionType);
}
