package com.example.hms.decorator.patient;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Patient;
import com.example.hms.utils.FileConstants;
import com.example.hms.utils.IOStreamManager;
import com.example.hms.utils.Utils;

import java.io.IOException;

public class ListPatientAction  extends BaseDecorator<Patient> {
    BaseAction<Patient> basePatient;

    public ListPatientAction(BaseAction<Patient> basePatient) {
        this.basePatient = basePatient;
    }
    @Override
    public void performAction(Patient patient, ActionType actionType) {
        basePatient.performAction(patient,actionType);
        try {
            String builder = "Patient List: \n" +
                    IOStreamManager.readFile("patient.txt");
            IOStreamManager.writeFileWithAppend(FileConstants.outputTestFilePath, builder);
        } catch (IOException ioException) {
            Utils.showIOErrorMessage();
        }
    }
}
