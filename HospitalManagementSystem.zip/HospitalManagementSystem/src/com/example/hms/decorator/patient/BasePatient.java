package com.example.hms.decorator.patient;

import com.example.hms.decorator.BaseAction;
import com.example.hms.model.ActionType;
import com.example.hms.model.Patient;
import com.example.hms.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class BasePatient extends BaseAction<Patient> {

    public BasePatient() {
        super();
    }
    @Override
    public void performAction(Patient patient, ActionType actionType) {
        switch (actionType) {
            case ADD:addPatient(patient); break;
            case DELETE:removePatient(patient.getPatientId()); break;
        }
    }

    public void addPatient(Patient patient) {
        baseList.add(patient);
        Utils.orderPatients(baseList);
    }

    public void removePatient(int patientID) {
        Utils.removePatientById(baseList, patientID);
        Utils.orderPatients(baseList);
    }

}
