package com.example.hms.decorator.patient;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Patient;
import com.example.hms.utils.FileConstants;
import com.example.hms.utils.IOStreamManager;
import com.example.hms.utils.Utils;

import java.io.IOException;

public class DeletePatientAction extends BaseDecorator<Patient> {
    BaseAction<Patient> basePatient;

    public DeletePatientAction(BaseAction<Patient> basePatient) {
        this.basePatient = basePatient;
    }

    @Override
    public void performAction(Patient patient, ActionType actionType) {
        Patient deletedPatient = Utils.getPatientById(basePatient.getBaseList(),patient.getPatientId());
        basePatient.performAction(patient,actionType);
        try {
            String patients = Utils.listOfPatientToString(basePatient.getBaseList());
            if(!patients.isEmpty()) {
                IOStreamManager.writeFileWithClean(FileConstants.patientFilePath, patients);

                StringBuilder builder = new StringBuilder();

                if (deletedPatient != null) {
                    builder
                            .append("Patient").append(" ")
                            .append(deletedPatient.getPatientName()).append(" ")
                            .append("removed").append("\n");

                    IOStreamManager.writeFileWithAppend(FileConstants.outputTestFilePath,builder.toString());
                }
            }
        } catch (IOException ioException) {
            Utils.showIOErrorMessage();
        }
    }
}
