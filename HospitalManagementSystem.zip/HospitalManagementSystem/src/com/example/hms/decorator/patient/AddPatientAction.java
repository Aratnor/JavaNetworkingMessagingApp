package com.example.hms.decorator.patient;

import com.example.hms.decorator.BaseAction;
import com.example.hms.decorator.BaseDecorator;
import com.example.hms.model.ActionType;
import com.example.hms.model.Patient;
import com.example.hms.utils.FileConstants;
import com.example.hms.utils.IOStreamManager;
import com.example.hms.utils.Utils;

import java.io.IOException;

public class AddPatientAction extends BaseDecorator<Patient> {
    BaseAction<Patient> basePatient;

    public AddPatientAction(BaseAction<Patient> basePatient) {
        this.basePatient = basePatient;
    }

    @Override
    public void performAction(Patient patient, ActionType actionType) {
        basePatient.performAction(patient, actionType);
        try {
            IOStreamManager.writeFileWithAppend(FileConstants.patientFilePath, patient.toString());
            StringBuilder builder = new StringBuilder();
            builder
                    .append("Patient ")
                    .append(patient.getPatientId())
                    .append(" ")
                    .append(patient.getPatientName())
                    .append(" ").append("added").append("\n");
            IOStreamManager.writeFileWithAppend(FileConstants.outputTestFilePath, builder.toString());
        } catch (IOException ioException) {
            Utils.showIOErrorMessage();
        }
    }
}
