package com.example.hms.utils;

import com.example.hms.dao.AdmissionRepository;
import com.example.hms.dao.PatientRepository;
import com.example.hms.model.Admission;
import com.example.hms.model.Examination;
import com.example.hms.model.Patient;

import java.io.IOException;

public class InstructionReader extends Thread {
    String[] instructions;
    int currentInstruction;
    AdmissionRepository admissionRepository;
    PatientRepository patientRepository;
    public InstructionReader() {
        try {
            instructions = IOStreamManager.readFileByLine(FileConstants.inputFilePath);
            admissionRepository = new AdmissionRepository();
            patientRepository = new PatientRepository();
        } catch (IOException ioException) {
            Utils.showIOErrorMessage();
        }
    }

    @Override
    public void run() {
        super.run();
        while (currentInstruction < instructions.length) {
            applyInstruction(instructions[currentInstruction++]);
        }

    }

    public void applyInstruction(String instruction) {
        String [] splitedInstruction = instruction.replaceAll("\\s{2,}", " ").trim().split(" ");
        switch (splitedInstruction[0]) {
            case "AddPatient": {
                if(splitedInstruction.length >= 5) {
                    int patientId = Integer.parseInt(splitedInstruction[1]);
                    String patientName = splitedInstruction[2];
                    String patientSurName = splitedInstruction[3];
                    String phoneNumber = splitedInstruction[4];
                    StringBuilder address = new StringBuilder();
                    for (int i = 5; i < splitedInstruction.length; i++) {
                        address.append(splitedInstruction[i]);
                    }
                    Patient patient = new
                            Patient(patientId, patientName, patientSurName, phoneNumber, address.toString());
                    patientRepository.addData(patient);
                }
                break;
            }
            case "RemovePatient": {
                int patientId = Integer.parseInt(splitedInstruction[1]);
                patientRepository.removeData(new Patient(patientId));
                break;
            }
            case "CreateAdmission": {
                int admissionId = Integer.parseInt(splitedInstruction[1]);
                int patientId = Integer.parseInt(splitedInstruction[2]);
                admissionRepository.addData(new Admission(admissionId,patientId));
                break;
            }
            case "AddExamination": {
                int admissionId = Integer.parseInt(splitedInstruction[1]);
                admissionRepository.addExamination(new Examination(splitedInstruction[2],splitedInstruction[3],splitedInstruction[4]),admissionId);
                break;
            }
            case "TotalCost": {
                int admissionId = Integer.parseInt(splitedInstruction[1]);
                admissionRepository.printTotalCost(admissionId);
                break;
            }
            case "ListPatients": {
                patientRepository.listData();
                break;
            }
        }
    }
}
