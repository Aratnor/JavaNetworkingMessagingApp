package com.example.hms.utils;

import java.io.*;
import java.util.ArrayList;

public class IOStreamManager {

    //FileNotFoundException
    public static String readFile(String fileName) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        StringBuilder builder = new StringBuilder();

        String nextLine;

        while((nextLine = reader.readLine()) != null) {
            builder.append(nextLine).append("\n");
        }

        reader.close();
        return builder.toString();
    }

    public static String[] readFileByLine(String fileName) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        ArrayList<String> lines = new ArrayList<>();

        String nextLine;

        while((nextLine = reader.readLine()) != null) {
           lines.add(nextLine);
        }

        reader.close();
        return lines.toArray(new String[lines.size()]);
    }

    public static void writeFileWithAppend(String fileName, String value) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));

        writer.write(value);

        writer.close();
    }

    public static void writeFileWithClean(String fileName, String value) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));

        writer.write(value);

        writer.close();
    }
}
