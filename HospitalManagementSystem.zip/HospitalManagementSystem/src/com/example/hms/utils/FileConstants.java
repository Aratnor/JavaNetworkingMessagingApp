package com.example.hms.utils;

public class FileConstants {
    public final static String patientFilePath = "patient.txt";
    public final static String admissionFilePath = "admission.txt";
    public final static String inputFilePath = "input.txt";
    public final static String outputTestFilePath = "output.txt";
    public final static int doctorVisitCost = 15;
    public final static int imagingCost = 10;
    public final static int testsCost = 7;
    public final static int measurementCost = 5;
    public final static int inPatientCost = 10;
    public final static int outPatientCost = 5;
}
