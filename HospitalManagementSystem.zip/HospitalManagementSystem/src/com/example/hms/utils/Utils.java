package com.example.hms.utils;

import com.example.hms.model.Admission;
import com.example.hms.model.Examination;
import com.example.hms.model.Patient;
import com.sun.tools.javac.util.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Utils {

    public static String listOfPatientToString(List<Patient> patients) {
        StringBuilder builder = new StringBuilder();

        for(Patient patient: patients) {
            builder.append(patient.toString());
        }

        return builder.toString();
    }

    public static void orderPatients(List<Patient> patients) {
        for(int i = 0;i<patients.size()-1;i++) {
            Patient first = patients.get(i);
            int lower = 0;
            for(int j = i+1;j<patients.size();j++) {
                Patient second = patients.get(j);

                if( first.getPatientId() > second.getPatientId()) {
                    lower = j;
                    first = second;
                }
            }
            Patient temp = first;
            Patient lowest = patients.get(lower);
            patients.set(i,lowest);
            patients.set(lower,temp);
        }
    }

    public static Patient getPatientById(List<Patient> patients, int patientId) {
        for(Patient patient: patients) {
            if(patient.getPatientId() == patientId) {
                return patient;
            }
        }
        return null;
    }

    public static void removePatientById(List<Patient> patients,int idToBeRemoved) {
        Patient patientToBeRemoved = null;
        for(Patient patient : patients) {
            if(patient.getPatientId() == idToBeRemoved) {
                patientToBeRemoved = patient;
            }
        }
        if(patientToBeRemoved != null)
            patients.remove(patientToBeRemoved);
    }
    public static void removeAdmissionById(List<Admission> admissions, int idToBeRemoved) {
        Admission admissionToBeRemoved = null;
        for( Admission admission: admissions) {
            if(admission.getAdmissionId() == idToBeRemoved) {
                admissionToBeRemoved = admission;
                break;
            }
        }
        if(admissionToBeRemoved != null) {
            admissions.remove(admissionToBeRemoved);
        }


    }

    public static List<Patient> getPatientsByInstructions(String [] instructions) {
        List<Patient> patients = new ArrayList<>();
        for(String instruction :instructions) {
            String [] splitedInstruction = instruction.replace("\t", " ").replaceAll("\\s{2,}", " ").trim().split(" ");
            if (splitedInstruction.length >= 4) {
                int patientId = Integer.parseInt(splitedInstruction[0]);
                String patientName = splitedInstruction[1];
                String patientSurName = splitedInstruction[2];
                String phoneNumber = splitedInstruction[3];
                StringBuilder address = new StringBuilder();
                for (int i = 4; i < splitedInstruction.length; i++) {
                    address.append(splitedInstruction[i]);
                }
                Patient patient = new
                        Patient(patientId, patientName, patientSurName, phoneNumber, address.toString());
                patients.add(patient);

            }
        }
        return patients;
    }

    public static Admission getAdmissionById(List<Admission> admissions, int admissionId) {
        for(Admission admission: admissions) {
            if(admission.getAdmissionId() == admissionId)
                return admission;
        }
        return null;
    }

    public static void showIOErrorMessage() {
        System.out.println("Something wrong with your file path or " +
                "fileName please put them under same directory with project");
    }

    public static void addExaminationToAdmission(List<Admission> list, int admissionId, Examination examination) {
        for(Admission admission : list) {
            if(admission.getAdmissionId() == admissionId) {
                StringBuilder builder = new StringBuilder();
                builder
                        .append(examination.getPatientType()).append(" ")
                        .append("examination").append(" added to admission ")
                        .append(admissionId).append("\n");
                try {
                    IOStreamManager.writeFileWithAppend(FileConstants.outputTestFilePath,builder.toString());
                    IOStreamManager.writeFileWithAppend(FileConstants.admissionFilePath, examination.getStringValue()+"\n");
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                admission.addExamination(examination);
                break;
            }
        }
    }

    public static List<Admission> getAdmissionByInstruction(String [] instructions) {
        List<Admission> admissions = new ArrayList<>();
        Admission currentAdmission = null;
        for (String instruction : instructions) {
            String[] splitedInstruction = instruction.replace("\t", " ").replaceAll("\\s{2,}", " ").trim().split(" ");
            try {
                if(splitedInstruction[0].contains("in") || splitedInstruction[0].contains("out")) {
                    if (currentAdmission != null && splitedInstruction.length >= 3) {
                        currentAdmission.addExamination(new Examination(splitedInstruction[0],splitedInstruction[1],splitedInstruction[2]));
                    }
                } else {
                    int admissionId = Integer.parseInt(splitedInstruction[0]);
                    int patientId = Integer.parseInt(splitedInstruction[1]);
                    currentAdmission = new Admission(admissionId,patientId);
                    admissions.add(currentAdmission);
                }

            } catch(NumberFormatException e){

            }
        }
        return admissions;
    }
}
